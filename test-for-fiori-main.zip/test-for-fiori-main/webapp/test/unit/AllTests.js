sap.ui.define([
	"app/testprojectui5b27/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
