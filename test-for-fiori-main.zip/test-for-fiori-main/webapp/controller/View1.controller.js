sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("app.testprojectui5b27.controller.View1", {
        onInit() {
        }
    });
});